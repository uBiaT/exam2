﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Security.Principal;
using System.Threading.Tasks;
using Test2.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Test2.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            SanPham sp = new SanPham();
            return View(sp);
        }

        [HttpPost]
        public IActionResult Privacy(string tenSanPham, int soLuong, double donGia)
        {
            SanPham sp = new SanPham();
            sp.TenSanPham = tenSanPham.ToString();
            sp.SoLuong = soLuong.ToString();
            sp.DonGia = donGia.ToString("N0");
            sp.TamTinh = (soLuong * donGia).ToString("N0");
            return View(sp);
        }

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}
    }
}