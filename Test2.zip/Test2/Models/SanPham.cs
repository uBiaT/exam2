﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test2.Models
{
    public class SanPham
    {
        public string TenSanPham { get; set; }
        public string SoLuong { get; set; }
        public string DonGia { get; set; }
        public string TamTinh { get; set; }
        //public string TongSoTien { get; set; }

        public SanPham()
        {
            TenSanPham = string.Empty;
            SoLuong = string.Empty;
            DonGia = string.Empty;
            TamTinh = string.Empty;
            //TongSoTien = string.Empty;
        }

    }
}
